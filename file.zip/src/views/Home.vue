<template>
  <div class="main--view">
    <div class="main--home">
      <video controls>
        <source
          src="https://testbadger.s3.amazonaws.com/Forest_15_2_Videvo.mov"
          type="video/mp4"
        />
        <source
          src="https://testbadger.s3.amazonaws.com/Forest_15_2_Videvo.mov"
          type="video/ogg"
        />
        Your browser does not support the video tag.
      </video>
    </div>
    <RightSide />
  </div>
</template>

<script>
import RightSide from "@/components/Right-sidebar.vue";
export default {
  name: "Home",
  components: {
    RightSide,
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
video {
  width: 100%;
  height: 100%;
}
</style>
