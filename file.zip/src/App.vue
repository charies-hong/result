<template>
  <div class="container">
    <div class="main-area">
      <Header />
      <div class="content-wrap">
        <div class="content">
          <router-view />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Header from "@/layout/Header.vue";

export default {
  name: "App",
  components: {
    Header,
  },
  mounted() {},
};
</script> 
