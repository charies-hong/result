<template>
  <div class="right--side">
    <div class="right--side-box">
      <video controls>
        <source
          src="https://testbadger.s3.amazonaws.com/190404_04_KaninBovec_Drone_026.mp4"
          type="video/mp4"
        />
        <source
          src="https://testbadger.s3.amazonaws.com/190404_04_KaninBovec_Drone_026.mp4"
          type="video/ogg"
        />
        Your browser does not support the video tag.
      </video>
    </div>
    <div class="right--side-box">
      <video controls>
        <source
          src="https://testbadger.s3.amazonaws.com/Forest_15_2_Videvo.mov"
          type="video/mp4"
        />
        <source
          src="https://testbadger.s3.amazonaws.com/Forest_15_2_Videvo.mov"
          type="video/ogg"
        />
        Your browser does not support the video tag.
      </video>
    </div>
    <div class="right--side-box">
      <video controls>
        <source
          src="https://testbadger.s3.amazonaws.com/a27.mp4"
          type="video/mp4"
        />
        <source
          src="https://testbadger.s3.amazonaws.com/a27.mp4"
          type="video/ogg"
        />
        Your browser does not support the video tag.
      </video>
    </div>
  </div>
</template>

<script>
export default {
  name: "Right-sidebar",
};
</script>

<style>
.right--side-box video {
  width: 100%;
  height: 100%;
}
</style>